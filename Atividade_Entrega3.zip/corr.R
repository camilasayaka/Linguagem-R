#Exercicio 3

corr = function(diretorio, limiar = 0){
  saidas = sapply(list.files(diretorio), function(arq){
    arquivo = paste(diretorio, arq, sep = "/")
    dados = na.omit(read.csv(arquivo))
    
    if (nrow(dados) >= limiar) { # foram aceitas as solu��es com os operadores > e >=
      return(cor(dados$sulfato, dados$nitrato))
    }
    return(NA)
  }, USE.NAMES = F)
  
  if (sum(!is.na(saidas)) == 0)
    return(numeric())
  
  return(saidas[!is.na(saidas)])
}








