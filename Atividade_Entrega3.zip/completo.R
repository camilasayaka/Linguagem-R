#Exercicio 2

completo <- function(diretorio, id=1:332) {
  nobs <- c() # vetor com o n° de observacoes de cada arquivo
  vetor <- dir(diretorio) # vetor com os nomes dos arquivos do diretorio

  for (i in vetor[id]) {# percorre todo os elementos de 'vetor'
    dataframe <- read.csv(paste0(diretorio,'/',i)) # le o arquivo i
    dataframe <- na.omit(dataframe) # tira os na
    nobs <- c(nobs,nrow(dataframe)) # guarda o n° de observacoes no vetor 'nobs'
  }
  return(data.frame("id"= id,"nobs"=nobs)) # retorna o id com os respectivos n° de observacoes
}


