#Exercicio 1

media_poluente <- function(diretorio, poluente, id=1:332) {
  soma <- 0 # soma total dos dados do poluente
  num <- 0 # numero de dados total do poluente
  vetor <- dir(diretorio) # vetor com os nomes dos arquivos do diretorio

  for (i in vetor[id]) { # percorre todo os elementos de 'vetor'
    dataframe <- read.csv(paste0(diretorio,'/',i)) # le o arquivo i
    dataframe <- dataframe[!is.na(dataframe[,poluente]),] # tira os na
    soma <- soma + sum(dataframe[,poluente]) # soma os dados da coluna e adiciona em 'soma'
    num <- num+nrow(dataframe) # adiciona a quantidade de dados do poluente do arquivo

  }

  return(sum(soma)/num) # retorna a media
}
